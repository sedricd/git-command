package com.sedric;

public class ThreadB extends Thread {
	@Override
	public void run() {
		System.out.println("ThreadB is running");

		System.out.println("ThreaB is sleeping!");

		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("ThreadB is end!");
	}

}

package com.sedric.thread;

public class TestMain {

	public static void main(String[] args) {
		BreadContainer container = new BreadContainer();

		MakerThread maker = new MakerThread();

		SellerThread seller = new SellerThread();

		container.setMaker(maker);

		container.setSeller(seller);

		seller.setBreadContainer(container);

		maker.setContainer(container);

		seller.start();

		maker.start();

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		for (int i = 0; i <= 20; i++) {
			if (container.getBreadNum() == 0) {
				System.out.println("当没有面包的时候，调用了interrrupt方法之前的seller线程状态是：" + seller.getState());
				seller.interrupt();
				System.out.println("当没有面包的时候，调用了interrrupt方法之后的seller线程状态是：" + seller.getState());
			}
		}
	}
}

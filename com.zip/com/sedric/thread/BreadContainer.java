package com.sedric.thread;

import java.util.ArrayList;
import java.util.List;

public class BreadContainer {

	private SellerThread seller;

	private MakerThread maker;

	private int breadNum = 0;

	private List<Bread> breadList = new ArrayList<Bread>();

	private boolean isMakerStoped = false;

	public void addBread(Bread bread) {

		breadList.add(bread);

		breadNum += 1;

		System.out.println("新做了一个面包，通知了卖家可以卖面包了！现在有" + breadNum + "个面包！");

		synchronized (seller) {

			if (Thread.State.BLOCKED == seller.getState() || Thread.State.TIMED_WAITING == seller.getState()) {
				System.out.println("有了新的面包，但是卖家在休息，通知卖家开始工作！");
			}
			seller.notifyAll();

			System.out.println("新做了一个面包之后，卖家的状态是：" + seller.getState());
		}
	}

	public void sellBread() {

		if (breadNum == 0 || breadList.size() <= 0) {
			System.out.println("面包已经卖光了，面包商开始休息了！");
			synchronized (seller) {
				Thread.yield();
			}
			System.out.println("面包卖光之后，卖家的状态是：" + seller.getState());
		} else {

			breadList.remove(0);

			breadNum -= 1;

			System.out.println("卖掉了一个面包，还剩" + breadNum + "个面包！");
		}
	}

	public SellerThread getSeller() {
		return seller;
	}

	public void setSeller(SellerThread seller) {
		this.seller = seller;
	}

	public MakerThread getMaker() {
		return maker;
	}

	public void setMaker(MakerThread maker) {
		this.maker = maker;
	}

	public boolean isMakerStoped() {
		return isMakerStoped;
	}

	public void setMakerStoped(boolean isMakerStoped) {
		this.isMakerStoped = isMakerStoped;
	}

	public int getBreadNum() {
		return breadNum;
	}

	public void setBreadNum(int breadNum) {
		this.breadNum = breadNum;
	}

	public List<Bread> getBreadList() {
		return breadList;
	}

	public void setBreadList(List<Bread> breadList) {
		this.breadList = breadList;
	}

}

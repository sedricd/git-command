package com.sedric.thread;

public class MakerThread extends Thread {

	private BreadContainer container;

	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {

			Bread bread = new Bread();
			bread.setColor("red");
			bread.setIndex(i);

			boolean isSleep = Math.floor(Math.random() * 10) > 5;

			if (isSleep) {
				try {
					Thread.sleep(10000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

			container.addBread(bread);

			System.out.println("第" + (i + 1) + "次做面包！");

		}

		container.setMakerStoped(true);

		System.out.println("面包做完了！不做新的面包了！============");
	}

	public BreadContainer getContainer() {
		return container;
	}

	public void setContainer(BreadContainer container) {
		this.container = container;
	}

}

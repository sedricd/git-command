package com.sedric.thread;

public class SellerThread extends Thread {

	private BreadContainer breadContainer;

	@Override
	public void run() {
		int i = 0;
		while (!(breadContainer.isMakerStoped() && breadContainer.getBreadNum() == 0)) {

			boolean isSleep = Math.floor(Math.random() * 10) > 5;

			if (isSleep) {
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					System.out.println("卖家休息呗终止，继续开始卖面包！");
				}
			}

			breadContainer.sellBread();

			System.out.println("第" + (i + 1) + "次卖面包！");

			i += 1;

		}

		System.out.println("面包卖完了！");
	}

	public BreadContainer getBreadContainer() {
		return breadContainer;
	}

	public void setBreadContainer(BreadContainer breadContainer) {
		this.breadContainer = breadContainer;
	}

}

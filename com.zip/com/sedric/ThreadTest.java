package com.sedric;

/**
 * 
 * Thread.sleep方法使当前线程进入停滞状态，所以执行sleep()的线程在指定的时间内肯定不会执行（释放资源）,
 * 但是sleep函数不会释放锁资源.
 * 
 * yield() 只是使当前线程重新回到可执行状态，所以执行yield()线程有可能在进入到可执行状态后马上又被执行.
 * 只能使同优先级的线程有执行的机会。同样, yield()也不会释放锁资源.
 * 
 * sleep和yield的区别在于, sleep可以使优先级低的线程得到执行的机会, 而yield只能使同优先级的线程有执行的机会.
 * 
 * Thread.interrupt()方法不会中断一个正在运行的线程。
 * 
 * interrupt方法不会中断一个正在运行的线程.就是指线程如果正在运行的过程中, 去调用此方法是没有任何反应的. 为什么呢, 因为这个方法只是提供给
 * 被阻塞的线程, 即当线程调用了.Object.wait, Thread.join, Thread.sleep三种方法之一的时候,
 * 再调用interrupt方法, 才可以中断刚才的阻塞而继续去执行线程.
 * 
 * 也就是说interrupt可以终止线程的wait、join和sleep阻塞，让线程继续后续的操作。
 * 
 * join() 当join(0)时等待一个线程直到它死亡, 当join(1000)时等待一个线程1000纳秒,后回到主线程继续执行.
 * 哪个线程调用另一个线程的Join方法，哪个线程开始等待另一个线程执行结束。join函数为线程安全函数, 即同步函数。
 * 
 * 
 * 
 * @author 369105
 * 
 */
public class ThreadTest {

	public static void main(String[] args) {
		System.out.println("主线程开始执行!");

		LocalThread localThread = new LocalThread();

		try {

			localThread.start();

			System.out.println("当前的总线程数是：" + Thread.activeCount());

			System.out.println("主函数中第一次监控到的线程状态是：" + localThread.getState());

			synchronized (localThread) {

				System.out.println("主线程释放资源!");
				// 使用wait时，释放出了锁资源，LocalThread线程在调用wait方法时，进入的是TIMED_WAITING状态
				// localThread.wait(5000l);
				// 使用Thread.sleep时，不释放锁资源，LocalThread线程调用wait方法时，进入的是BLOCKED状态
				Thread.sleep(5000l);

				System.out.println("执行wait方法时，数字增加到：" + ThreadParam.getNum());

				System.out.println("执行wait方法时，主函数中第二次监控到的线程状态是：" + localThread.getState());
			}

			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			System.out.println("主函数中第三次监控到的线程状态是：" + localThread.getState());

		} catch (Exception e1) {
			e1.printStackTrace();
		}

		// localThread.notify();
		// try {
		// localThread.wait();
		//
		// // System.out.println("执行wait方法之后的线程状态是：" + localThread.getState());
		//
		// // localThread.notify();
		// //
		// // System.out.println("执行notify方法之后的线程状态是：" +
		// // localThread.getState());
		// } catch (InterruptedException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }

		// synchronized (localThread) {
		// localThread.notifyAll();
		// }

	}
}

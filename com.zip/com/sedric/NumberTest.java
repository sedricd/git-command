package com.sedric;

public class NumberTest {

	public static void main(String[] args) {
		Integer a = new Integer(1);

		Integer b = new Integer(1);

		System.out.println(a.equals(b));
	}
}

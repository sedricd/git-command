package com.sedric;

public class ThreadA extends Thread {

	private ThreadB threadB;

	@Override
	public void run() {
		System.out.println("thread A is running!");

		long t1 = 0l;
		long t2 = 0l;

		for (int i = 0; i < 1000; i++) {
			if (i == 100) {
				t1 = System.currentTimeMillis();
				try {
					System.out.println("开始等待threadB执行结束！");
					threadB.join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			if (i == 101) {
				t2 = System.currentTimeMillis();
				System.out.println("threadA等待threadB等待了" + (t2 - t1) + "毫秒！");
			}
		}

		System.out.println("thread A is end!");
	}

	public ThreadB getThreadB() {
		return threadB;
	}

	public void setThreadB(ThreadB threadB) {
		this.threadB = threadB;
	}

}

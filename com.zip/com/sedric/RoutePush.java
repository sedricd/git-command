package com.sedric;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

public class RoutePush {

	public static final String URL = "http://sale.sf-go.com/router/mock";

	// public static final String URL = "http://localhost:8094/router/mock";

	public static void main(String[] args) {

		List<String[]> routeList = readECSXls(new File("e:\\route\\a.xls"));

		File outFile = new File("e:\\route\\routeResponse.txt");
		FileWriter fw = null;
		try {
			fw = new FileWriter(outFile, true);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		for (String[] dataArr : routeList) {
			Map<String, String> params = new HashMap<String, String>();
			params.put("orderNo", dataArr[1]);
			params.put("logisticsNo", dataArr[6]);
			params.put("address", dataArr[4]);
			params.put("remark", dataArr[3]);
			params.put("opCode", dataArr[5]);
			params.put("acceptTime", dataArr[2]);
			try {
				String response = WebUtil.doPost(URL, params, 3000, 3000);
				String result = "第" + dataArr[0] + "行-" + "订单号-" + dataArr[1] + "-" + "运单号-" + dataArr[6];
				if (response.indexOf("操作成功") > 0) {
					fw.write(result + "推送成功！" + "\n");
				} else {
					fw.write(result + "推送失败！" + "\n");
				}
			} catch (IOException e) {
				String result = "第" + dataArr[0] + "行-" + "订单号-" + dataArr[1] + "-" + "运单号-" + dataArr[6];
				try {
					fw.write(result + "推送失败！" + "\n");
				} catch (IOException e1) {
					e.printStackTrace();
				}
				e.printStackTrace();
			}
		}
		if (null != fw) {
			try {
				fw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private static List<String[]> readECSXls(File file) {
		POIFSFileSystem fs;
		HSSFWorkbook wb;
		HSSFSheet sheet = null;
		HSSFRow row;
		FileInputStream fin = null;

		List<String[]> totalData = new ArrayList<String[]>(7000);
		try {

			fin = new FileInputStream(file);
			fs = new POIFSFileSystem(fin);
			wb = new HSSFWorkbook(fs);
			sheet = wb.getSheetAt(0);

			// 得到总行数
			int rowNum = sheet.getLastRowNum();

			row = sheet.getRow(0);
			int colNum = row.getPhysicalNumberOfCells();

			for (int curRow = 0; curRow <= rowNum; curRow++) {
				String[] data = new String[colNum + 1];
				row = sheet.getRow(curRow);
				data[0] = String.valueOf(curRow);
				int j = 0;
				try {
					while (j < colNum) {
						data[j + 1] = ExcelUtil.getHSSFCellValue(row, j);
						j++;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				totalData.add(data);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (null != fin) {
				try {
					fin.close();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		}
		return totalData;
	}
}

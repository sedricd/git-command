package com.sedric;

public class ThreadParam {

	public static int num = 1;

	public static int getNum() {
		return num;
	}

	public static void setNum(int num) {
		ThreadParam.num = num;
	}

	public synchronized static void numIncrement() {
		num += 1;
	}
}

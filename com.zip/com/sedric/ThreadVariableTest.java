package com.sedric;

public class ThreadVariableTest implements Runnable {

	public static void main(String[] args) {

		ThreadVariableTest test1 = new ThreadVariableTest();

		new Thread(test1).start();
		new Thread(test1).start();
	}

	private int i;

	@Override
	public void run() {
		System.out.println("thread is start!");

		while (true) {
			System.out.println("current variable values is " + i);

			try {
				Thread.sleep((long) Math.random() * 1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			if (i == 10) {
				break;
			}

			i += 1;
		}

	}

}

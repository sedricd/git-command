package com.sedric;

public class JoinTest {

	public static void main(String[] args) {
		ThreadA threadA = new ThreadA();
		ThreadB threadB = new ThreadB();

		threadA.setThreadB(threadB);

		threadA.start();

		threadB.start();

		while (true) {
			if (threadA.getState() != Thread.State.RUNNABLE) {
				System.out.println("thread A is run interrupt");
				threadA.interrupt();

				break;
			}

		}

		System.out.println("main thread is end!");
	}
}

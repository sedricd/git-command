package com.sedric;

public class InterruptTest extends Thread {

	private boolean isStoped = false;

	public static void main(String[] args) {
		InterruptTest stop = new InterruptTest();

		stop.start();

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("stop线程执行了中断！");

		stop.interrupt();

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("主程序执行结束");

		stop.setIsStop(true);

		System.exit(0);
	}

	@Override
	public void run() {

		while (!this.isStoped) {
			System.out.println("stop线程正在执行");
		}

		System.out.println("线程执行了stop方法之后，还在执行！");
	}

	public void setIsStop(boolean isStop) {
		this.isStoped = isStop;
	}

}

package com.sedric;

public class Test {

	public static void main(String[] args) {
		String str = "123";
		String str1 = null;
		System.out.println("123" + String.valueOf(str1));

		String a1 = new String("a");
		String a2 = new String("a").intern();
		String a3 = "a";

		System.out.println(a1 == "a");
		System.out.println(a2 == "a");

		// Integer i3 = 3;
		// Integer i1 = new Integer(1);
		// Integer i2 = new Integer(1);
		//
		// System.out.println(i1 == i2);
		// System.out.println(i1 == i3);
		// for (int i = 0; i < 10; i++) {
		// System.out.println(Math.random());
		// }

	}
}

package com.sedric;

public class LocalThread extends Thread {

	@Override
	public void run() {
		System.out.println("从属线程开始执行！");

		// synchronized (this) {}

		long time1 = 0l;
		long time2 = 0l;
		for (int i = 1; i <= 400000; i++) {

			if (i == 1) {
				time1 = System.currentTimeMillis();
			} else {
				time1 = time2;
			}

			if (i == 100000) {
				synchronized (this) {
					try {
						// Thread.sleep(10000l);
						System.out.println("从属线程释放资源!");
						wait(10000l);
						System.out.println("开始执行从属线程的wait方法，执行结束，等待时间：" + (time2 - time1));
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}

			ThreadParam.numIncrement();

			time2 = System.currentTimeMillis();

			// if (i == 500) {
			//
			// }
			// if (i == 501) {
			// System.out.println("当前输出的数字是：" + i);
			// time2 = System.currentTimeMillis();
			// }

			if (time2 - time1 > 5000) {
				System.out.println("执行输出数字" + i + "时，循环在此时进入了超过5秒的等待！");
			}
		}

		System.out.println("线程的状态是：" + Thread.currentThread().getState());

	}
}

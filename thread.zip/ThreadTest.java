package com.sedric;

/**
 * 
 * Thread.sleep方法使当前线程进入停滞状态，所以执行sleep()的线程在指定的时间内肯定不会执行（释放资源）,
 * 但是sleep函数不会释放锁资源.
 * 
 * yield() 只是使当前线程重新回到可执行状态，所以执行yield()线程有可能在进入到可执行状态后马上又被执行.
 * 只能使同优先级的线程有执行的机会。同样, yield()也不会释放锁资源.
 * 
 * @author 369105
 * 
 */
public class ThreadTest {

	public static void main(String[] args) {
		System.out.println("主线程开始执行!");

		LocalThread localThread = new LocalThread();

		try {

			localThread.start();

			System.out.println("当前的总线程数是：" + Thread.activeCount());

			System.out.println("主函数中第一次监控到的线程状态是：" + localThread.getState());

			synchronized (localThread) {

				System.out.println("主线程释放资源!");
				// 使用wait时，释放出了锁资源，LocalThread线程在调用wait方法时，进入的是TIMED_WAITING状态
				// localThread.wait(5000l);
				// 使用Thread.sleep时，不释放锁资源，LocalThread线程调用wait方法时，进入的是BLOCKED状态
				Thread.sleep(5000l);

				System.out.println("执行wait方法时，数字增加到：" + ThreadParam.getNum());

				System.out.println("执行wait方法时，主函数中第二次监控到的线程状态是：" + localThread.getState());
			}

			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			System.out.println("主函数中第三次监控到的线程状态是：" + localThread.getState());

		} catch (Exception e1) {
			e1.printStackTrace();
		}

		// localThread.notify();
		// try {
		// localThread.wait();
		//
		// // System.out.println("执行wait方法之后的线程状态是：" + localThread.getState());
		//
		// // localThread.notify();
		// //
		// // System.out.println("执行notify方法之后的线程状态是：" +
		// // localThread.getState());
		// } catch (InterruptedException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }

		// synchronized (localThread) {
		// localThread.notifyAll();
		// }

	}
}

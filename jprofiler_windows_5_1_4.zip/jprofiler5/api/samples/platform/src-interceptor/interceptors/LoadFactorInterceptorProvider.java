package interceptors;

import com.jprofiler.api.agent.interceptor.Interceptor;
import com.jprofiler.api.agent.interceptor.InterceptorProvider;

// The interceptor provider class is specified with as a VM parameter as
// -Djprofiler.interceptorProvider=interceptor.LoadFactorInterceptorProvider
// so the JProfiler agent can initialize all interceptors at startup.
public class LoadFactorInterceptorProvider implements InterceptorProvider {

    public Interceptor[] getInterceptors() {
        return new Interceptor[] {
            new LoadFactorInterceptor()
        };
    }
}

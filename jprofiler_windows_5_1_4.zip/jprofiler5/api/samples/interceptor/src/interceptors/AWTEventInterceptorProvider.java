package interceptors;

import com.jprofiler.api.agent.interceptor.Interceptor;
import com.jprofiler.api.agent.interceptor.InterceptorProvider;

// The interceptor provider class is specified with as a VM parameter as
// -Djprofiler.interceptorProvider=interceptor.AWTEventInterceptorProvider
// so the JProfiler agent can initialize all interceptors at startup.
// The interceptor class and all referenced classes have to be in the boot classpath
// so they can be accessed by the profiling agent. 
public class AWTEventInterceptorProvider implements InterceptorProvider {

    public Interceptor[] getInterceptors() {
        return new Interceptor[] {
            new AWTEventInterceptor()
        };
    }
}
